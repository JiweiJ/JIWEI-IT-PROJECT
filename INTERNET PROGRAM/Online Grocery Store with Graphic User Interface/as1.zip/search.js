document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.getElementById("search-input");
    const searchBtn = document.getElementById("search-btn");

    if (!searchInput || !searchBtn) {
        console.warn("Search input or button not found.");
        return;
    }

    // 回车触发搜索
    searchInput.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (query !== "") {
                searchProducts(query);
            }
        }
    });

    // 点击按钮触发搜索
    searchBtn.addEventListener("click", function () {
        const query = searchInput.value.trim();
        if (query !== "") {
            searchProducts(query);
        }
    });
});

// 搜索请求
function searchProducts(query) {
    fetch('get_products.php?search=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("搜索产品时出错：", error);
        });
}
