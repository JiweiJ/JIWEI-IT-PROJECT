// shopping_cart.js

// 全局购物车对象：记录每个产品的已加入数量、单价、库存和名称
let cart = {};

// 更新购物车显示：计算购物车内所有产品的总数量和总价，并更新页面显示
function updateCartUI() {
    let totalItems = 0;
    let totalPrice = 0;
    for (let id in cart) {
        totalItems += cart[id].quantity;
        totalPrice += cart[id].quantity * cart[id].price;
    }
    const cartInfo = document.getElementById("cart-info");
    if (cartInfo) {
        cartInfo.textContent = `${totalItems} items / $${totalPrice.toFixed(2)}`;
    }
}

// 渲染产品数据，同时在每个产品下方添加 “Add” 按钮，按钮中加入 data-name 属性
function renderProducts(data) {
    const productGrid = document.querySelector('.product-grid');
    // 设置为每行显示4个产品
    productGrid.style.gridTemplateColumns = "repeat(4, 1fr)";
    let html = "";
    if (data && Array.isArray(data.products)) {
        data.products.forEach(product => {
            // 兼容字段：如果 product.product_name 不存在，则尝试 product.name
            const prodName = product.product_name || product.name || "Unknown Product";
            html += `
            <div class="product-item">
                <img src="${product.product_id}.png" alt="${prodName}">
                <h3>${prodName}</h3>
                <p>Price: $${product.unit_price}</p>
                <p>Quantity: ${product.unit_quantity}</p>
                <p>${parseInt(product.in_stock) < 1 ? 'out of stock' : 'In Stock: ' + product.in_stock}</p>
                <button class="add-btn" 
                    data-product-id="${product.product_id}" 
                    data-name="${prodName}"
                    data-price="${product.unit_price}" 
                    data-stock="${product.in_stock}"
                    ${parseInt(product.in_stock) < 1 ? 'disabled' : ''}>
                    Add
                </button>
            </div>
            `;
        });
        productGrid.innerHTML = html;
        // 为所有新增的 "Add" 按钮绑定点击事件
        bindAddButtons();
    } else {
        productGrid.innerHTML = "<p>没有找到相关商品。</p>";
    }
}

// 为所有 "Add" 按钮绑定点击事件，处理加入购物车逻辑
function bindAddButtons() {
    const addButtons = document.querySelectorAll('.add-btn');
    addButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            const productId = btn.getAttribute('data-product-id');
            const name = btn.getAttribute('data-name');
            console.log("Adding product", productId, name); // 调试输出
            const price = parseFloat(btn.getAttribute('data-price'));
            const stock = parseInt(btn.getAttribute('data-stock'));
            // 获取当前购物车中该产品已添加的数量
            const currentQty = cart[productId] ? cart[productId].quantity : 0;
            if (currentQty < stock) {
                if (!cart[productId]) {
                    cart[productId] = { quantity: 0, price: price, stock: stock, name: name };
                }
                cart[productId].quantity++;
                updateCartUI();
                if (cart[productId].quantity >= stock) {
                    btn.disabled = true;
                }
            } else {
                btn.disabled = true;
            }
        });
    });
}
