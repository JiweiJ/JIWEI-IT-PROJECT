document.addEventListener("DOMContentLoaded", function() {
    // 保存主页初始的产品网格内容
    const productGrid = document.querySelector('.product-grid');
    const homeContent = productGrid.innerHTML;

    // 定义恢复主页的函数
    function loadHomePage() {
        const main = document.querySelector('main');
        const html = `
            <div class="product-grid">
                <div class="product-item"><img src="Freeze.png" alt="Freeze"><h3>Freeze</h3></div>
                <div class="product-item"><img src="Drink.png" alt="Drink"><h3>Drink</h3></div>
                <div class="product-item"><img src="Fresh.png" alt="Fresh"><h3>Fresh</h3></div>
                <div class="product-item"><img src="Pet.png" alt="Pet"><h3>Pet</h3></div>
                <div class="product-item household"><img src="Household.png" alt="Household"><h3>Household</h3></div>
            </div>
        `;
        main.innerHTML = html;
        bindHomeImages();  // ✅ 每次回到主页后重新绑定图片点击
    }
    

    // 为 logo 和 Home 按钮绑定点击事件，返回主页
    const logo = document.querySelector('.logo img');
    if (logo) {
        logo.style.cursor = "pointer"; // 添加点击样式
        logo.addEventListener("click", function(e) {
            e.stopPropagation();
            loadHomePage();
        });
    }
    // 假设第一个 <li> 为 Home 按钮
    const homeNav = document.querySelector('nav > ul > li:first-child');
    if (homeNav) {
        homeNav.style.cursor = "pointer";
        homeNav.addEventListener("click", function(e) {
            e.stopPropagation();
            loadHomePage();
        });
    }

    // 为主页中显示的产品图片绑定点击事件
    function bindHomeImages() {
        const productItems = document.querySelectorAll('.product-grid .product-item');
        productItems.forEach(function(item) {
            const img = item.querySelector('img');
            if (img) {
                // 根据 alt 属性判断是哪个分类
                const alt = img.getAttribute('alt').toLowerCase();
                // 先移除之前绑定的事件，防止重复绑定（如果需要）
                img.replaceWith(img.cloneNode(true));
                const newImg = item.querySelector('img');
                switch (alt) {
                    case "freeze":
                        newImg.style.cursor = "pointer";
                        newImg.addEventListener("click", function() {
                            loadFreezeProducts();
                        });
                        break;
                    case "drink":
                        newImg.style.cursor = "pointer";
                        newImg.addEventListener("click", function() {
                            loadDrinkProducts();
                        });
                        break;
                    case "fresh":
                        newImg.style.cursor = "pointer";
                        newImg.addEventListener("click", function() {
                            loadFreshProducts();
                        });
                        break;
                    case "pet":
                        newImg.style.cursor = "pointer";
                        newImg.addEventListener("click", function() {
                            loadPetProducts();
                        });
                        break;
                    case "household":
                        newImg.style.cursor = "pointer";
                        newImg.addEventListener("click", function() {
                            loadHouseholdProducts();
                        });
                        break;
                }
            }
        });
    }
    
    // 初次绑定主页图片点击事件
    bindHomeImages();
});

window.loadHomePage = loadHomePage;
window.loadFreezeProducts = loadFreezeProducts;
window.loadDrinkProducts = loadDrinkProducts;
window.loadFreshProducts = loadFreshProducts;
window.loadPetProducts = loadPetProducts;
window.loadHouseholdProducts = loadHouseholdProducts;
