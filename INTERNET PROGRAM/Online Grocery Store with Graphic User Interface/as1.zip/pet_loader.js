// pet_loader.js

document.addEventListener("click", function (e) {
    const target = e.target.closest("li"); // 监听点击的 li 元素
    if (!target) return;

    const text = target.textContent.trim();

    // 针对顶级菜单
    if (text === "Drink") loadDrinkProducts();
    if (text === "Freeze") loadFreezeProducts();
    if (text === "Fresh") loadFreshProducts();
    if (text === "Pet") loadPetProducts();
    if (text === "Household") loadHouseholdProducts();

    // 针对下拉子菜单
    switch (text) {
        case "Soft Drink": loadSoftDrinkProducts(); break;
        case "water": loadWaterProducts(); break;
        case "Dairy": loadDairyProducts(); break;
        case "Alcohol": loadAlcoholProducts(); break;

        case "Fast Food": loadFastFoodProducts(); break;
        case "Meat": loadFreezeMeatProducts(); break;
        case "Fruits and Vegetables": loadFruitsAndVegetablesProducts(); break;
        case "Ice Cream": loadIceCreamProducts(); break;

        case "Vegetable": loadFreshVegetableProducts(); break;
        case "Seafood": loadFreshSeafoodProducts(); break;
        case "Fruits": loadFreshFruitsProducts(); break;
        case "spice": case "Spice": loadFreshSpiceProducts(); break;

        case "Dog": loadDogProducts(); break;
        case "Cat": loadCatProducts(); break;
        case "Others": loadOthersProducts(); break;

        case "Kitchen": loadKitchenProducts(); break;
        case "Bathroom": loadBathroomProducts(); break;
        case "Electrical Equipment": loadElectricalEquipmentProducts(); break;
    }
});


// 加载 Pet 顶级（显示 product_id 为 30,32,33,34 的产品）
function loadPetProducts() {
    fetch('get_products.php?category=pet')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Pet 产品时出错：", error);
        });
}

// 加载 Dog（显示 product_id 为 30 的产品）
function loadDogProducts() {
    fetch('get_products.php?category=dog')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Dog 产品时出错：", error);
        });
}

// 加载 Cat（显示 product_id 为 32 的产品）
function loadCatProducts() {
    fetch('get_products.php?category=cat')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Cat 产品时出错：", error);
        });
}

// 加载 Others（显示 product_id 为 33,34 的产品）
function loadOthersProducts() {
    fetch('get_products.php?category=others')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Others 产品时出错：", error);
        });
}

// 通用函数：根据返回的数据动态渲染产品网格（每行显示4个产品），并添加“Add”按钮
function renderProducts(data) {
    const productGrid = document.querySelector('.product-grid');
    productGrid.style.gridTemplateColumns = "repeat(4, 1fr)";
    let html = "";
    if (data && Array.isArray(data.products)) {
        data.products.forEach(product => {
            html += `
            <div class="product-item">
                <img src="${product.product_id}.png" alt="${product.product_name}">
                <h3>${product.product_name}</h3>
                <p>Price: $${product.unit_price}</p>
                <p>Quantity: ${product.unit_quantity}</p>
                <p>${parseInt(product.in_stock) < 1 ? 'out of stock' : 'In Stock: ' + product.in_stock}</p>
                <button class="add-btn"
                    data-product-id="${product.product_id}"
                    data-name="${product.product_name}"
                    data-price="${product.unit_price}"
                    data-stock="${product.in_stock}"
                    ${parseInt(product.in_stock) < 1 ? 'disabled' : ''}>
                    Add
                </button>
            </div>
            `;
        });
        productGrid.innerHTML = html;
        // 为所有新增的 "Add" 按钮绑定点击事件
        bindAddButtons();
    } else {
        productGrid.innerHTML = "<p>没有找到相关商品。</p>";
    }
}
