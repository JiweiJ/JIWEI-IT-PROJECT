<?php
header("Content-Type: application/json");

// 获取POST提交的JSON数据
$orderData = json_decode(file_get_contents("php://input"), true);

if (!$orderData || !isset($orderData['cart'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid order data.']);
    exit;
}

// 数据库连接信息，根据实际情况修改
$host = 'localhost';
$db   = 'assignment1';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 开始事务处理
    $pdo->beginTransaction();
    
    foreach ($orderData['cart'] as $productId => $item) {
        // 获取当前库存
        $stmt = $pdo->prepare("SELECT in_stock FROM products WHERE product_id = ?");
        $stmt->execute([$productId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => "Product ID {$productId} not found."]);
            exit;
        }
        $currentStock = (int)$row['in_stock'];
        
        // 检查库存是否足够
        if ($currentStock < $item['quantity']) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => "Insufficient stock for product ID {$productId}."]);
            exit;
        }
        
        // 计算更新后的库存
        $newStock = $currentStock - $item['quantity'];
        
        // 更新产品库存
        $stmt = $pdo->prepare("UPDATE products SET in_stock = ? WHERE product_id = ?");
        $stmt->execute([$newStock, $productId]);
    }
    
    // 此处你可以添加订单保存到订单表的逻辑，例如将配送信息和订单详情保存到orders和order_items表中
    
    // 提交事务
    $pdo->commit();
    
    echo json_encode(['success' => true, 'message' => 'Order placed successfully.']);
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
