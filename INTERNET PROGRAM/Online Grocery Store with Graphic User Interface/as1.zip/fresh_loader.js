// fresh_loader.js

document.addEventListener("DOMContentLoaded", function() {
    // 为 Fresh 顶级菜单项绑定点击事件（仅针对顶级 Fresh，不响应下拉菜单项点击）
    const navItems = document.querySelectorAll('nav > ul > li');
    navItems.forEach(function(li) {
        if (li.textContent.trim().startsWith("Fresh")) {
            li.addEventListener("click", function(e) {
                if (e.target === li) {
                    e.stopPropagation();
                    loadFreshProducts();
                }
            });
        }
    });

    // 为 Fresh 下拉菜单中的各子项绑定点击事件
    const dropdownItems = document.querySelectorAll('nav .dropdown-menu li');
    dropdownItems.forEach(function(item) {
        const text = item.textContent.trim();
        switch(text) {
            case "Meat":
    item.addEventListener("click", function(e) {
        e.stopPropagation();
        loadFreshMeatProducts();
    });
    break;
            case "Vegetable":
                item.addEventListener("click", function(e) {
                    e.stopPropagation();
                    loadFreshVegetableProducts();
                });
                break;
            case "Seafood":
                item.addEventListener("click", function(e) {
                    e.stopPropagation();
                    loadFreshSeafoodProducts();
                });
                break;
            case "Fruits":
                item.addEventListener("click", function(e) {
                    e.stopPropagation();
                    loadFreshFruitsProducts();
                });
                break;
            case "spice":
            case "Spice":
                item.addEventListener("click", function(e) {
                    e.stopPropagation();
                    loadFreshSpiceProducts();
                });
                break;
        }
    });
});

// 加载 Fresh 顶级（显示 product_id: 11,12,13,14,15,16,17,18,20,21）
function loadFreshProducts() {
    fetch('get_products.php?category=fresh')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh 产品时出错：", error);
        });
}

// 加载 Fresh 下的 Meat（显示 product_id: 11,12,13）
function loadFreshMeatProducts() {
    fetch('get_products.php?category=freshmeat')  // ✅ 注意这里是 freshmeat

        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh Meat 产品时出错：", error);
        });
}

// 加载 Fresh 下的 Vegetable（显示 product_id: 14,15）
function loadFreshVegetableProducts() {
    fetch('get_products.php?category=freshvegetable')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh Vegetable 产品时出错：", error);
        });
}

// 加载 Fresh 下的 Seafood（显示 product_id: 16）
function loadFreshSeafoodProducts() {
    fetch('get_products.php?category=freshseafood')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh Seafood 产品时出错：", error);
        });
}

// 加载 Fresh 下的 Fruits（显示 product_id: 17）
function loadFreshFruitsProducts() {
    fetch('get_products.php?category=freshfruits')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh Fruits 产品时出错：", error);
        });
}

// 加载 Fresh 下的 spice（显示 product_id: 18,20,21）
function loadFreshSpiceProducts() {
    fetch('get_products.php?category=freshspice')
        .then(response => response.json())
        .then(data => {
            renderProducts(data);
        })
        .catch(error => {
            console.error("加载 Fresh spice 产品时出错：", error);
        });
}

// 通用函数：根据返回的数据动态渲染产品网格（每行显示4个产品），并添加“Add”按钮
function renderProducts(data) {
    const productGrid = document.querySelector('.product-grid');
    productGrid.style.gridTemplateColumns = "repeat(4, 1fr)";
    let html = "";
    if (data && Array.isArray(data.products)) {
        data.products.forEach(product => {
            html += `
            <div class="product-item">
                <img src="${product.product_id}.png" alt="${product.product_name}">
                <h3>${product.product_name}</h3>
                <p>Price: $${product.unit_price}</p>
                <p>Quantity: ${product.unit_quantity}</p>
                <p>${parseInt(product.in_stock) < 1 ? 'out of stock' : 'In Stock: ' + product.in_stock}</p>
                <button class="add-btn" 
                    data-product-id="${product.product_id}" 
                    data-name="${product.product_name}"
                    data-price="${product.unit_price}" 
                    data-stock="${product.in_stock}"
                    ${parseInt(product.in_stock) < 1 ? 'disabled' : ''}>
                    Add
                </button>
            </div>
            `;
        });
        productGrid.innerHTML = html;
        // 为所有新增的 "Add" 按钮绑定点击事件
        bindAddButtons();
    } else {
        productGrid.innerHTML = "<p>没有找到相关商品。</p>";
    }
}
